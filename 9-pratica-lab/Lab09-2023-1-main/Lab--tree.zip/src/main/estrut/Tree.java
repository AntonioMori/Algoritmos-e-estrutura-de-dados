package estrut;

public interface Tree extends EstruturaElementar{
    public int[] preOrdem();
    public int[] emOrdem();
    public int[] posOrdem();
}
